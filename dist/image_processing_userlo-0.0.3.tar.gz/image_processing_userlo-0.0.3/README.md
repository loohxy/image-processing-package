# package_name

Description. 
The package image_processing_userlo is used to:
Processing
	  - Histrogram matching
	  - Structural similarity
      - Resize image
	Utils:
      - Read image
	  - Save image
	  - Plot image
	  - Plot result
	  - Plot histogram
	

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_userlo

```bash
pip install image_processing_userlo
```

## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
```

## Author
Lorena

## License
[MIT](https://choosealicense.com/licenses/mit/)